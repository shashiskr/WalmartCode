***** Angular WalmartDemo Project ********** 


Project Versions:
	Node : v12.18.4
	Angular : 10.1.1
	NPM : 6.14.6


How to start-----------

$ cd WalmartDemo
$ ng serve

URL :  http://localhost:4200

Note : Run ng serve for a dev server. Navigate to http://localhost:4200/. The app will automatically reload.




